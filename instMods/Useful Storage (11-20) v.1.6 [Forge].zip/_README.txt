To install:
	Simply drag the contents of this folder into your minecraft.jar
	(Make sure you delete META-INF and have Forge installed!)

	The oh.class (EntityAnimal) causes passive mobs to run away from the Scarecow
	mob (in the exact same way as creepers from ocelots). It is COMPLETELY optional
	and only needs to be installed if you want this behavior to occur.
	
The version is v.1.6. This mod will only work with Minecraft [1.4.5].

Known issues:
	None at the moment!

Changelog:
	v.1.6 (11/20)
		- updated to Minecraft 1.4.5
		- fixed SMP support (?) [Forge]
	v.1.5 (11/15)
		- cleaned-up Forge config
		- added SMP support (?) [Forge]
	v.1.4.2 (11/2)
		- updated for Minecraft 1.4.2
		- fixed charcoal block not being harvest-able
		- tweaked Material settings for different blocks
			- redstone is now treated as a circuit rather than a ground block
			- coal and charcoal have different sounds and now both require pick to harvest
	v.1.4.1 (9/11)
		- restructured code to remove need for compatibility patches
		- moved textures to /vanillawithsprinkles/textures/*
		- improved compatibility with mod-loading programs
	v.1.4 (8/25)
		- internal changes
			cleaned up a lot of code
			made compatibility improvements where possible
		- updated for Forge v.4.0
	v.1.3 (8/18)
		- updated for Minecraft 1.3.2
		- re-enabled Scarecow
		- removed reliance on base class edits (BlockPumpkin)
		- tweaked Scarecow texture to better match wheat block
	v.1.2 (8/16)
		- updated for Minecraft 1.3.1
		- temporarily disabled Scarecrow mob due to compatibility issues
		- tweaked coal block texture - softened border
		- tweaked wheat and redstone (powered and unpowered) block textures - adjusted color
		- changed redstone block stepsound
		- added optional charcoal block w/ option to use separate texture
		- added config options for coal/charcoal block smelting
			can lower number of resources to craft (to eight)
			OR up smelting power of the block (to nine coal equivalent)
		- made redstone block more useful; powering or unpowering the block will trigger 
		   block updates in the surrounding 5x5 area (can be adjusted in config)
		- added SMP support (ModLoaderMP)
	v.1.1 (7/10)
		- fixed Scarecrow taking damage in warm biomes and when wet	
	v.1.0 (6/27)
		- release

Please leave feedback/any other questions you may have on the official topic:
	http://www.minecraftforum.net/topic/1298016-132
You can also contact me and follow updates through my YouTube channel:
	http://www.youtube.com/koopinator

Otherwise, I hope you enjoy! :D

- Ian