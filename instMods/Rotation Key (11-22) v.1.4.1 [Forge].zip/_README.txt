To install:
	Simply drag the contents of this folder into your minecraft.jar
	~ OR ~
	Use the entire packaged folder with the loader of your choice
	(Make sure you delete META-INF and have Forge installed!)

	The vk.class (ItemSlab) is required for the new slab types, but completely optional
	if you choose not to install them.
	
The version is v.1.4.1. This mod will only work with Minecraft [1.4.5].

Known issues:
	- at the moment vertical slabs cannot be placed to form double slabs
	
Changelog:
	v.1.4.1 (11/22)
		- added compatibility fix for Better Blocks & Items
	v.1.4 (11/20)
		- updated to Minecraft 1.4.5
		- fixed SMP support (?) [Forge]
	v.1.3 (11/12)
		- fixed rotation on stairs
		- fixed placing slabs on stairs and log blocks
		- fixed Forge config
		- fixed vertical stone slabs not dropping correctly
		- fixed pick block on vertical slabs
		- added SMP support (?) [Forge]
	v.1.2 (11/5)
		- updated for Minecraft 1.4.2
		- added rotation support for Ender chests
		- fixed rotated placement for chests
		- all blocks can now be rotated as long as the same block is not being held
			empty hands no longer required
	v.1.1.1 (9/11)
		- restructured code to remove need for compatibility patches
		- moved textures to /vanillawithsprinkles/textures/*
		- improved compatibility with mod-loading programs
	v.1.1 (8/25)
		- internal changes
			cleaned up a lot of the code
			made compatibility improvments where possible
		- fixed furnace issues
		- changed block rotation
			all blocks will now rotate only when there is nothing in hand
			slabs will now rotate on right-click by default
		- removed slab-specific left-click config option
		- updated for Forge v.4.0
	v.1.0.1 (8/20)
		- rebranded (lol..)
	v.1.0 (8/20)
		- release

Please leave feedback/any other questions you may have on the official topic:
	http://www.minecraftforum.net/topic/1298016-132
You can also contact me and follow updates through my YouTube channel:
	http://www.youtube.com/koopinator

Otherwise, I hope you enjoy! :D

- Ian